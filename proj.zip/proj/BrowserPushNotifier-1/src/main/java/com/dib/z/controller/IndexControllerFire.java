package com.dib.z.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IndexControllerFire {


	  @GetMapping("/hello")
	  public String getIndex(Model model) {
		  return "base";
	  }
	
}
